﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Hospital1
{
    public partial class Main : Form
    {
        SqlConnection con = new SqlConnection(
            @"Data Source=AHMED;Initial Catalog=Hospitaldb;Integrated Security=True;");

        public Main()
        {
            InitializeComponent();
            bind_data();
        }

        private void Emptying()
        {
            textBox1.ReadOnly = false;
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";

            for (int i = 0; i < checkedListBox1.Items.Count; i++)
            {
                checkedListBox1.SetItemChecked(i, false);
            }
        }

        private void bind_data()
        {
            con.Open();

            DataTable dt = new DataTable();
            string sql = "select * from users";
            SqlDataAdapter da = new SqlDataAdapter(sql, con);
            da.Fill(dt);

            dataGridView1.DataSource = dt;

            dataGridView1.Columns[0].HeaderText = "اسم المستخدم";
            dataGridView1.Columns[1].HeaderText = "كلمة المرور";
            dataGridView1.Columns[2].HeaderText = "الموظفين";
            dataGridView1.Columns[3].HeaderText = "الأقسام";
            dataGridView1.Columns[4].HeaderText = "العيادات";
            dataGridView1.Columns[5].HeaderText = "الإستعلامات";
            dataGridView1.Columns[6].HeaderText = "إدارة المستخدمين";

            dataGridView1.Columns[1].Visible = false;

            dataGridView1.Columns[0].Width = 120;
            dataGridView1.Columns[2].Width = 120;
            dataGridView1.Columns[3].Width = 120;
            dataGridView1.Columns[4].Width = 120;

            con.Close();
        }

        private void Main_Load(object sender, EventArgs e)
        {
            bind_data();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            try
            {
                textBox1.Text =
                    dataGridView1.Rows[e.RowIndex].Cells["user_name"].Value.ToString();

                textBox2.Text =
                    dataGridView1.Rows[e.RowIndex].Cells["user_password"].Value.ToString();

                checkedListBox1.SetItemChecked(0,
                    Convert.ToBoolean(dataGridView1.Rows[e.RowIndex].Cells["Per1"].Value));

                checkedListBox1.SetItemChecked(1,
                    Convert.ToBoolean(dataGridView1.Rows[e.RowIndex].Cells["Per2"].Value));

                checkedListBox1.SetItemChecked(2,
                    Convert.ToBoolean(dataGridView1.Rows[e.RowIndex].Cells["Per3"].Value));

                checkedListBox1.SetItemChecked(3,
                    Convert.ToBoolean(dataGridView1.Rows[e.RowIndex].Cells["Per4"].Value));

                checkedListBox1.SetItemChecked(4,
                    Convert.ToBoolean(dataGridView1.Rows[e.RowIndex].Cells["Per5"].Value));

                textBox1.ReadOnly = true;
            }
            catch (Exception)
            {
                return;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Emptying();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int count = 0;
            SqlCommand cmd = new SqlCommand();

            con.Open();
            cmd.Connection = con;
            cmd.CommandText =
                "select * from users where user_name=@user_name";
            cmd.Parameters.AddWithValue("@user_name", textBox1.Text);

            SqlDataReader rd1 = cmd.ExecuteReader();
            while (rd1.Read())
            {
                count++;
            }
            rd1.Close();
            con.Close();
            cmd.Parameters.Clear();

            if (textBox1.Text.Trim() == "" || textBox2.Text.Trim() == "")
            {
                MessageBox.Show("الرجاء إكمال البيانات أولاً", "تنبيه",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (textBox2.Text != textBox3.Text)
            {
                MessageBox.Show("الرجاء مطابقة كلمة المرور", "تنبيه",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (count != 0)
            {
                MessageBox.Show("المستخدم موجود مسبقاً", "تنبيه",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                con.Open();
                cmd.Connection = con;
                cmd.CommandText =
                    "INSERT INTO users(user_name,user_password,Per1,Per2,Per3,Per4,Per5) " +
                    "values (@user_name,@user_password,@Per1,@Per2,@Per3,@Per4,@Per5)";

                cmd.Parameters.AddWithValue("@user_name", textBox1.Text);
                cmd.Parameters.AddWithValue("@user_password", textBox2.Text);
                cmd.Parameters.AddWithValue("@Per1", checkedListBox1.GetItemChecked(0));
                cmd.Parameters.AddWithValue("@Per2", checkedListBox1.GetItemChecked(1));
                cmd.Parameters.AddWithValue("@Per3", checkedListBox1.GetItemChecked(2));
                cmd.Parameters.AddWithValue("@Per4", checkedListBox1.GetItemChecked(3));
                cmd.Parameters.AddWithValue("@Per5", checkedListBox1.GetItemChecked(4));

                cmd.ExecuteNonQuery();
                con.Close();
                cmd.Parameters.Clear();

                MessageBox.Show("تمت الإضافة بنجاح", "نجاح",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                bind_data();
                Emptying();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText =
                    "update users set Per1=@Per1,Per2=@Per2,Per3=@Per3,Per4=@Per4,Per5=@Per5 " +
                    "where user_name=@user_name";

                cmd.Parameters.AddWithValue("@user_name", textBox1.Text);
                cmd.Parameters.AddWithValue("@Per1", checkedListBox1.GetItemChecked(0));
                cmd.Parameters.AddWithValue("@Per2", checkedListBox1.GetItemChecked(1));
                cmd.Parameters.AddWithValue("@Per3", checkedListBox1.GetItemChecked(2));
                cmd.Parameters.AddWithValue("@Per4", checkedListBox1.GetItemChecked(3));
                cmd.Parameters.AddWithValue("@Per5", checkedListBox1.GetItemChecked(4));

                cmd.ExecuteNonQuery();
                con.Close();
                cmd.Parameters.Clear();

                MessageBox.Show("تم التعديل بنجاح", "نجاح",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                bind_data();
                Emptying();
            }
            else
            {
                MessageBox.Show("الرجاء تحديد المستخدم أولاً", "تنبيه",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                DialogResult result = MessageBox.Show(
                    "هل أنت متأكد من حذف المستخدم؟",
                    "تأكيد",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning);

                if (result == DialogResult.Yes)
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandText =
                        "delete from users where user_name=@user_name";

                    cmd.Parameters.AddWithValue("@user_name", textBox1.Text);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    cmd.Parameters.Clear();

                    MessageBox.Show("تم الحذف بنجاح", "نجاح",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);

                    bind_data();
                    Emptying();
                }
            }
            else
            {
                MessageBox.Show("الرجاء تحديد المستخدم للحذف", "تنبيه",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            string sql = "select * from  users where user_name like '%" + textBox4.Text + "%'";
            SqlDataAdapter da = new SqlDataAdapter(sql, con);
            da.Fill(dt);

            dataGridView1.DataSource = dt;

            dataGridView1.Columns[0].HeaderText = "اسم المستخدم";
            dataGridView1.Columns[1].HeaderText = "كلمة المرور";
            dataGridView1.Columns[2].HeaderText = "الموظفين";
            dataGridView1.Columns[3].HeaderText = "الأقسام";
            dataGridView1.Columns[4].HeaderText = "العيادات";
            dataGridView1.Columns[5].HeaderText = "الإستعلامات";
            dataGridView1.Columns[6].HeaderText = "إدارة المستخدمين";

            dataGridView1.Columns[1].Visible = false;

            dataGridView1.Columns[0].Width = 120;
            dataGridView1.Columns[2].Width = 120;
            dataGridView1.Columns[3].Width = 120;
            dataGridView1.Columns[4].Width = 120;

            con.Close();
        }
    }
}
