﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Hospital1
{
    public partial class Clinics : Form
    {
        string connectionString =
            @"Data Source=AHMED;Initial Catalog=Hospitaldb;Integrated Security=True;";
        SqlConnection con;

        public Clinics()
        {
            InitializeComponent();
            con = new SqlConnection(connectionString);

            Load_Departments(); // تحميل الأقسام
            bind_data();        // تحميل العيادات
        }

        // =========================
        // تحميل الأقسام في ComboBox
        // =========================
        private void Load_Departments()
        {
            try 
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();

                SqlDataAdapter da = new SqlDataAdapter(
                    "SELECT dept_id, dept_name FROM Departments", con);

                DataTable dt = new DataTable();
                da.Fill(dt);

                comboDept.DataSource = dt;
                comboDept.DisplayMember = "dept_name";
                comboDept.ValueMember = "dept_id";
                comboDept.SelectedIndex = -1;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
        }

        // =========================
        // تحميل بيانات العيادات
        // =========================
        private void bind_data()
        {
            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();

                SqlDataAdapter da = new SqlDataAdapter(
                    @"SELECT Clinics_id,
                             Clinics_name,
                             Clinit_loc,
                             dept_id
                      FROM Clinics", con);

                DataTable dt = new DataTable();
                da.Fill(dt);

                dataGridView1.AutoGenerateColumns = true;
                dataGridView1.DataSource = dt;

                dataGridView1.Columns["Clinics_id"].HeaderText = "رقم العيادة";
                dataGridView1.Columns["Clinics_name"].HeaderText = "اسم العيادة";
                dataGridView1.Columns["Clinit_loc"].HeaderText = "الموقع";
                dataGridView1.Columns["dept_id"].HeaderText = "القسم";
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
        }

        // =========================
        // إضافة عيادة
        // =========================
        private void btn_add_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Trim() == "" ||
                textBox2.Text.Trim() == "" ||
                comboDept.SelectedValue == null)
            {
                MessageBox.Show("الرجاء إدخال جميع البيانات", "تنبيه");
                return;
            }

            try
            {
                SqlCommand cmd = new SqlCommand(
                    @"INSERT INTO Clinics (Clinics_name, Clinit_loc, dept_id)
                      VALUES (@name, @loc, @dept)", con);

                cmd.Parameters.AddWithValue("@name", textBox1.Text.Trim());
                cmd.Parameters.AddWithValue("@loc", textBox2.Text.Trim());
                cmd.Parameters.AddWithValue("@dept", comboDept.SelectedValue);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("تمت الإضافة بنجاح");
                bind_data();
                Emptying();
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }

        // =========================
        // تعديل عيادة
        // =========================
        private void btn_Edit_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("حدد عيادة للتعديل");
                return;
            }

            try
            {
                int id = Convert.ToInt32(
                    dataGridView1.CurrentRow.Cells["Clinics_id"].Value);

                SqlCommand cmd = new SqlCommand(
                    @"UPDATE Clinics
                      SET Clinics_name=@name,
                          Clinit_loc=@loc,
                          dept_id=@dept
                      WHERE Clinics_id=@id", con);

                cmd.Parameters.AddWithValue("@name", textBox1.Text.Trim());
                cmd.Parameters.AddWithValue("@loc", textBox2.Text.Trim());
                cmd.Parameters.AddWithValue("@dept", comboDept.SelectedValue);
                cmd.Parameters.AddWithValue("@id", id);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("تم التعديل بنجاح");
                bind_data();
                Emptying();
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }

        // =========================
        // حذف عيادة
        // =========================
        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("حدد عيادة للحذف");
                return;
            }

            DialogResult result = MessageBox.Show(
                "هل أنت متأكد من الحذف؟",
                "تأكيد",
                MessageBoxButtons.YesNo);

            if (result != DialogResult.Yes) return;

            try
            {
                int id = Convert.ToInt32(
                    dataGridView1.CurrentRow.Cells["Clinics_id"].Value);

                SqlCommand cmd = new SqlCommand(
                    "DELETE FROM Clinics WHERE Clinics_id=@id", con);

                cmd.Parameters.AddWithValue("@id", id);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("تم الحذف بنجاح");
                bind_data();
                Emptying();
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }

        // =========================
        // عند الضغط على صف
        // =========================
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //if (e.RowIndex < 0) return;

            //DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

            //// حسب ترتيب الأعمدة في bind_data()
            //textBox1.Text = row.Cells[1].Value.ToString(); // Clinics_name
            //textBox2.Text = row.Cells[2].Value.ToString(); // Clinit_loc
            //comboDept.SelectedValue = row.Cells[3].Value;  // dept_id
        }

        // =========================
        // تنظيف الحقول
        // =========================
        private void Emptying()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            comboDept.SelectedIndex = -1;
        }

        private void btn_Clear_Click(object sender, EventArgs e)
        {
            Emptying();
        }

        private void dataGridView1_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

            // حسب ترتيب الأعمدة في bind_data()
            textBox1.Text = row.Cells[1].Value.ToString(); // Clinics_name
            textBox2.Text = row.Cells[2].Value.ToString(); // Clinit_loc
            comboDept.SelectedValue = row.Cells[3].Value;  // dept_id

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();

                SqlDataAdapter da = new SqlDataAdapter(
                   "select * from  Clinics where Clinics_name like '%" + textBox3.Text + "%'"
                    , con);

                DataTable dt = new DataTable();
                da.Fill(dt);

                dataGridView1.AutoGenerateColumns = true;
                dataGridView1.DataSource = dt;

                dataGridView1.Columns["Clinics_id"].HeaderText = "رقم العيادة";
                dataGridView1.Columns["Clinics_name"].HeaderText = "اسم العيادة";
                dataGridView1.Columns["Clinit_loc"].HeaderText = "الموقع";
                dataGridView1.Columns["dept_id"].HeaderText = "القسم";
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
        }

        private void Clinics_Load(object sender, EventArgs e)
        {


        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
