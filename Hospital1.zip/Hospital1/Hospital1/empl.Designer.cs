﻿namespace Hospital1
{
    partial class empl
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.HireDate = new System.Windows.Forms.TextBox();
            this.Salary = new System.Windows.Forms.TextBox();
            this.Phone_Number = new System.Windows.Forms.TextBox();
            this.Email = new System.Windows.Forms.TextBox();
            this.Last_Name = new System.Windows.Forms.TextBox();
            this.First_Name = new System.Windows.Forms.TextBox();
            this.ID_lable = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_Clear = new System.Windows.Forms.Button();
            this.btn_Edit = new System.Windows.Forms.Button();
            this.btn_add = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Selecte_image = new System.Windows.Forms.Button();
            this.emp_Profile = new System.Windows.Forms.PictureBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label9 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emp_Profile)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(858, 44);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Hospital1.Properties.Resources._17698893222431;
            this.pictureBox1.Location = new System.Drawing.Point(323, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(39, 56);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei", 20F);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(357, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(153, 35);
            this.label1.TabIndex = 0;
            this.label1.Text = "ادارة الموظفين";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.HireDate);
            this.panel2.Controls.Add(this.Salary);
            this.panel2.Controls.Add(this.Phone_Number);
            this.panel2.Controls.Add(this.Email);
            this.panel2.Controls.Add(this.Last_Name);
            this.panel2.Controls.Add(this.First_Name);
            this.panel2.Controls.Add(this.ID_lable);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Location = new System.Drawing.Point(457, 48);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(389, 310);
            this.panel2.TabIndex = 1;
            // 
            // HireDate
            // 
            this.HireDate.Location = new System.Drawing.Point(18, 268);
            this.HireDate.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.HireDate.Name = "HireDate";
            this.HireDate.Size = new System.Drawing.Size(214, 20);
            this.HireDate.TabIndex = 11;
            // 
            // Salary
            // 
            this.Salary.Location = new System.Drawing.Point(18, 225);
            this.Salary.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Salary.Name = "Salary";
            this.Salary.Size = new System.Drawing.Size(214, 20);
            this.Salary.TabIndex = 10;
            // 
            // Phone_Number
            // 
            this.Phone_Number.Location = new System.Drawing.Point(18, 139);
            this.Phone_Number.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Phone_Number.Name = "Phone_Number";
            this.Phone_Number.Size = new System.Drawing.Size(214, 20);
            this.Phone_Number.TabIndex = 9;
            // 
            // Email
            // 
            this.Email.Location = new System.Drawing.Point(19, 182);
            this.Email.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(214, 20);
            this.Email.TabIndex = 9;
            // 
            // Last_Name
            // 
            this.Last_Name.Location = new System.Drawing.Point(18, 96);
            this.Last_Name.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Last_Name.Name = "Last_Name";
            this.Last_Name.Size = new System.Drawing.Size(214, 20);
            this.Last_Name.TabIndex = 8;
            // 
            // First_Name
            // 
            this.First_Name.Location = new System.Drawing.Point(18, 53);
            this.First_Name.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.First_Name.Name = "First_Name";
            this.First_Name.Size = new System.Drawing.Size(214, 20);
            this.First_Name.TabIndex = 7;
            // 
            // ID_lable
            // 
            this.ID_lable.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ID_lable.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ID_lable.Location = new System.Drawing.Point(18, 7);
            this.ID_lable.Name = "ID_lable";
            this.ID_lable.Size = new System.Drawing.Size(214, 19);
            this.ID_lable.TabIndex = 6;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft YaHei", 15F);
            this.label8.Location = new System.Drawing.Point(262, 271);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(107, 27);
            this.label8.TabIndex = 5;
            this.label8.Text = "تاريخ التوظيف";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft YaHei", 15F);
            this.label7.Location = new System.Drawing.Point(316, 227);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 27);
            this.label7.TabIndex = 1;
            this.label7.Text = "الراتب";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft YaHei", 15F);
            this.label6.Location = new System.Drawing.Point(250, 183);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(119, 27);
            this.label6.TabIndex = 4;
            this.label6.Text = "البريد الالكتروني";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft YaHei", 15F);
            this.label5.Location = new System.Drawing.Point(288, 139);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(81, 27);
            this.label5.TabIndex = 3;
            this.label5.Text = "رقم الهاتف";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft YaHei", 15F);
            this.label4.Location = new System.Drawing.Point(278, 95);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 27);
            this.label4.TabIndex = 2;
            this.label4.Text = "الاسم الاخير";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei", 15F);
            this.label3.Location = new System.Drawing.Point(286, 51);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 27);
            this.label3.TabIndex = 1;
            this.label3.Text = "الاسم الاول";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei", 15F);
            this.label2.Location = new System.Drawing.Point(278, 7);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 27);
            this.label2.TabIndex = 0;
            this.label2.Text = "رقم الموظف";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.panel3.Controls.Add(this.btn_delete);
            this.panel3.Controls.Add(this.btn_Clear);
            this.panel3.Controls.Add(this.btn_Edit);
            this.panel3.Controls.Add(this.btn_add);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 520);
            this.panel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(858, 76);
            this.panel3.TabIndex = 7;
            // 
            // btn_delete
            // 
            this.btn_delete.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn_delete.Font = new System.Drawing.Font("Microsoft YaHei", 15F);
            this.btn_delete.ForeColor = System.Drawing.Color.White;
            this.btn_delete.Image = global::Hospital1.Properties.Resources.person_cancel_35dp_FFFFFF_FILL0_wght400_GRAD0_opsz40;
            this.btn_delete.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_delete.Location = new System.Drawing.Point(263, 16);
            this.btn_delete.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(99, 49);
            this.btn_delete.TabIndex = 5;
            this.btn_delete.Text = "حذف";
            this.btn_delete.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_delete.UseVisualStyleBackColor = false;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click_1);
            // 
            // btn_Clear
            // 
            this.btn_Clear.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn_Clear.Font = new System.Drawing.Font("Microsoft YaHei", 15F);
            this.btn_Clear.ForeColor = System.Drawing.Color.White;
            this.btn_Clear.Image = global::Hospital1.Properties.Resources.filter_alt_35dp_FFFFFF_FILL0_wght400_GRAD0_opsz40;
            this.btn_Clear.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_Clear.Location = new System.Drawing.Point(30, 16);
            this.btn_Clear.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Clear.Name = "btn_Clear";
            this.btn_Clear.Size = new System.Drawing.Size(99, 49);
            this.btn_Clear.TabIndex = 3;
            this.btn_Clear.Text = "تصفية";
            this.btn_Clear.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Clear.UseVisualStyleBackColor = false;
            this.btn_Clear.Click += new System.EventHandler(this.btn_Clear_Click);
            // 
            // btn_Edit
            // 
            this.btn_Edit.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn_Edit.Font = new System.Drawing.Font("Microsoft YaHei", 15F);
            this.btn_Edit.ForeColor = System.Drawing.Color.White;
            this.btn_Edit.Image = global::Hospital1.Properties.Resources.person_edit_35dp_FFFFFF_FILL0_wght400_GRAD0_opsz40;
            this.btn_Edit.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_Edit.Location = new System.Drawing.Point(145, 16);
            this.btn_Edit.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Edit.Name = "btn_Edit";
            this.btn_Edit.Size = new System.Drawing.Size(99, 49);
            this.btn_Edit.TabIndex = 4;
            this.btn_Edit.Text = "تعديل";
            this.btn_Edit.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Edit.UseVisualStyleBackColor = false;
            this.btn_Edit.Click += new System.EventHandler(this.btn_Edit_Click);
            // 
            // btn_add
            // 
            this.btn_add.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn_add.Font = new System.Drawing.Font("Microsoft YaHei", 15F);
            this.btn_add.ForeColor = System.Drawing.Color.White;
            this.btn_add.Image = global::Hospital1.Properties.Resources.person_add_35dp_FFFFFF_FILL0_wght400_GRAD0_opsz40;
            this.btn_add.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_add.Location = new System.Drawing.Point(383, 16);
            this.btn_add.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(99, 49);
            this.btn_add.TabIndex = 6;
            this.btn_add.Text = "أضافة";
            this.btn_add.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_add.UseVisualStyleBackColor = false;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(0, 365);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(858, 150);
            this.dataGridView1.TabIndex = 8;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // Selecte_image
            // 
            this.Selecte_image.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.Selecte_image.Font = new System.Drawing.Font("Microsoft YaHei", 15F);
            this.Selecte_image.ForeColor = System.Drawing.Color.White;
            this.Selecte_image.Image = global::Hospital1.Properties.Resources.co_present_35dp_FFFFFF_FILL0_wght400_GRAD0_opsz40;
            this.Selecte_image.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Selecte_image.Location = new System.Drawing.Point(51, 216);
            this.Selecte_image.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Selecte_image.Name = "Selecte_image";
            this.Selecte_image.Size = new System.Drawing.Size(177, 49);
            this.Selecte_image.TabIndex = 7;
            this.Selecte_image.Text = "استعراض";
            this.Selecte_image.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Selecte_image.UseVisualStyleBackColor = false;
            this.Selecte_image.Click += new System.EventHandler(this.Selecte_image_Click);
            // 
            // emp_Profile
            // 
            this.emp_Profile.Image = global::Hospital1.Properties.Resources._236831;
            this.emp_Profile.Location = new System.Drawing.Point(51, 56);
            this.emp_Profile.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.emp_Profile.Name = "emp_Profile";
            this.emp_Profile.Size = new System.Drawing.Size(177, 128);
            this.emp_Profile.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.emp_Profile.TabIndex = 2;
            this.emp_Profile.TabStop = false;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Tahoma", 11F);
            this.textBox1.Location = new System.Drawing.Point(155, 10);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(236, 25);
            this.textBox1.TabIndex = 9;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.panel4.Controls.Add(this.pictureBox2);
            this.panel4.Controls.Add(this.textBox1);
            this.panel4.Controls.Add(this.label9);
            this.panel4.Location = new System.Drawing.Point(0, 321);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(451, 44);
            this.panel4.TabIndex = 17;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Hospital1.Properties.Resources.search_24dp_FFFFFF_FILL0_wght400_GRAD0_opsz24;
            this.pictureBox2.Location = new System.Drawing.Point(155, 10);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(28, 25);
            this.pictureBox2.TabIndex = 15;
            this.pictureBox2.TabStop = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft YaHei", 15F);
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(397, 7);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(42, 27);
            this.label9.TabIndex = 10;
            this.label9.Text = "بحث";
            // 
            // empl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(858, 596);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.Selecte_image);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.emp_Profile);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "empl";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.ShowIcon = false;
            this.Text = "ادارة الموظفين";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emp_Profile)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox HireDate;
        private System.Windows.Forms.TextBox Salary;
        private System.Windows.Forms.TextBox Phone_Number;
        private System.Windows.Forms.TextBox Email;
        private System.Windows.Forms.TextBox Last_Name;
        private System.Windows.Forms.TextBox First_Name;
        private System.Windows.Forms.Label ID_lable;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox emp_Profile;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btn_Clear;
        private System.Windows.Forms.Button btn_Edit;
        private System.Windows.Forms.Button Selecte_image;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label9;
    }
}

