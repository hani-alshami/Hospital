﻿namespace Hospital1
{
    partial class Main_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.User_Management = new System.Windows.Forms.Label();
            this.Clinics = new System.Windows.Forms.Label();
            this.btn_depaertmant = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.UserName = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.User_Management);
            this.panel1.Controls.Add(this.Clinics);
            this.panel1.Controls.Add(this.btn_depaertmant);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.UserName);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(5)))));
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1074, 85);
            this.panel1.TabIndex = 0;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft YaHei", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Image = global::Hospital1.Properties.Resources._1769888512499;
            this.label6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label6.Location = new System.Drawing.Point(442, 25);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(148, 36);
            this.label6.TabIndex = 7;
            this.label6.Text = "تسجيل الخروج";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // User_Management
            // 
            this.User_Management.Font = new System.Drawing.Font("Microsoft YaHei", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.User_Management.ForeColor = System.Drawing.Color.White;
            this.User_Management.Image = global::Hospital1.Properties.Resources._1769888725438;
            this.User_Management.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.User_Management.Location = new System.Drawing.Point(590, 25);
            this.User_Management.Name = "User_Management";
            this.User_Management.Size = new System.Drawing.Size(157, 36);
            this.User_Management.TabIndex = 6;
            this.User_Management.Text = "ادارة المستخدمين";
            this.User_Management.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.User_Management.Click += new System.EventHandler(this.label5_Click);
            // 
            // Clinics
            // 
            this.Clinics.Font = new System.Drawing.Font("Microsoft YaHei", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Clinics.ForeColor = System.Drawing.Color.White;
            this.Clinics.Image = global::Hospital1.Properties.Resources._17698893222661;
            this.Clinics.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Clinics.Location = new System.Drawing.Point(753, 25);
            this.Clinics.Name = "Clinics";
            this.Clinics.Size = new System.Drawing.Size(99, 39);
            this.Clinics.TabIndex = 4;
            this.Clinics.Text = "العيادات";
            this.Clinics.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Clinics.Click += new System.EventHandler(this.Clinics_Click);
            // 
            // btn_depaertmant
            // 
            this.btn_depaertmant.Font = new System.Drawing.Font("Microsoft YaHei", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_depaertmant.ForeColor = System.Drawing.Color.White;
            this.btn_depaertmant.Image = global::Hospital1.Properties.Resources._1769889322248;
            this.btn_depaertmant.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_depaertmant.Location = new System.Drawing.Point(865, 28);
            this.btn_depaertmant.Name = "btn_depaertmant";
            this.btn_depaertmant.Size = new System.Drawing.Size(88, 36);
            this.btn_depaertmant.TabIndex = 3;
            this.btn_depaertmant.Text = "الاقسام";
            this.btn_depaertmant.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_depaertmant.Click += new System.EventHandler(this.btn_depaertmant_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Image = global::Hospital1.Properties.Resources._1769889322243;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label1.Location = new System.Drawing.Point(969, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 36);
            this.label1.TabIndex = 2;
            this.label1.Text = "الموظفين";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label1.Click += new System.EventHandler(this.label1_Click_1);
            this.label1.MouseEnter += new System.EventHandler(this.label1_MouseEnter);
            this.label1.MouseLeave += new System.EventHandler(this.label1_MouseLeave);
            // 
            // UserName
            // 
            this.UserName.AutoSize = true;
            this.UserName.Font = new System.Drawing.Font("Tahoma", 12F);
            this.UserName.ForeColor = System.Drawing.Color.White;
            this.UserName.Location = new System.Drawing.Point(77, 35);
            this.UserName.Name = "UserName";
            this.UserName.Size = new System.Drawing.Size(48, 19);
            this.UserName.TabIndex = 1;
            this.UserName.Text = "name";
            this.UserName.Click += new System.EventHandler(this.label1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Hospital1.Properties.Resources._236831;
            this.pictureBox1.Location = new System.Drawing.Point(3, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(68, 64);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 526);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1074, 35);
            this.panel2.TabIndex = 1;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Hospital1.Properties.Resources.cardiology_103dp_A8E2FF_FILL0_wght400_GRAD0_opsz48;
            this.pictureBox2.Location = new System.Drawing.Point(347, 137);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(419, 246);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 8;
            this.pictureBox2.TabStop = false;
            // 
            // Main_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1074, 561);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Main_Form";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Main_Form_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel2;
        public System.Windows.Forms.Label btn_depaertmant;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.Label Clinics;
        public System.Windows.Forms.Label label6;
        public System.Windows.Forms.Label User_Management;
        public System.Windows.Forms.Label UserName;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}

