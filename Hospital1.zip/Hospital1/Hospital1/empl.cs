﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Forms;

namespace Hospital1
{
    public partial class empl : Form
    {
        SqlConnection con = new SqlConnection(
            "Data Source=AHMED;Initial Catalog=Hospitaldb;Integrated Security=True;");

        byte[] StudentImage;
        byte[] StaticImage;

        public empl()
        {
            InitializeComponent();
            this.Load += new EventHandler(empl_Load); // مهم لـ VS2012
        }

        // =========================
        // Form Load
        // =========================
        private void empl_Load(object sender, EventArgs e)
        {
            bind_data("select * from Employees");

            if (emp_Profile.Image != null)
                StaticImage = ConvertImage(emp_Profile);
        }

        // =========================
        // Convert Image to Byte[]
        // =========================
        private byte[] ConvertImage(PictureBox pictureBox)
        {
            if (pictureBox.Image == null)
                return null;

            using (MemoryStream ms = new MemoryStream())
            {
                pictureBox.Image.Save(ms, ImageFormat.Png);
                return ms.ToArray();
            }
        }

        // =========================
        // Clear Fields
        // =========================
        public void Emptying()
        {
            First_Name.Text = "";
            Last_Name.Text = "";
            Phone_Number.Text = "";
            Salary.Text = "";
            Email.Text = "";
            HireDate.Text = "";

            if (StaticImage != null)
            {
                using (MemoryStream ms = new MemoryStream(StaticImage))
                {
                    emp_Profile.Image = Image.FromStream(ms);
                }
            }
            else
            {
                emp_Profile.Image = null;
            }

            StudentImage = null;
        }

        // =========================
        // Select Image
        // =========================
        private void Selecte_image_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Image Files|*.png;*.jpg;*.jpeg;*.bmp";

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                emp_Profile.Image = Image.FromFile(openFileDialog1.FileName);
                StudentImage = File.ReadAllBytes(openFileDialog1.FileName);
            }
        }

        // =========================
        // Add Employee
        // =========================
        private void btn_add_Click(object sender, EventArgs e)
        {
            if (First_Name.Text == "")
            {
                MessageBox.Show("الرجاء التصفية قبل الاضافة", "تنبيه",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (Last_Name.Text.Trim() != "" &&
                Email.Text.Trim() != "" &&
                Phone_Number.Text != "" &&
                Salary.Text != "" &&
                HireDate.Text.Trim() != "" &&
                StudentImage != null)
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;

                cmd.CommandText = @"INSERT INTO Employees
                (First_Name, Last_Name, Phone, Email, Salary, Hire_Date, Image)
                VALUES
                (@First_Name, @Last_Name, @Phone, @Email, @Salary, @Hire_Date, @Image)";

                cmd.Parameters.AddWithValue("@First_Name", First_Name.Text);
                cmd.Parameters.AddWithValue("@Last_Name", Last_Name.Text);
                cmd.Parameters.AddWithValue("@Phone", Phone_Number.Text);
                cmd.Parameters.AddWithValue("@Email", Email.Text);

                double salary;
                if (!double.TryParse(Salary.Text, out salary))
                {
                    MessageBox.Show("الرجاء إدخال الراتب بشكل رقمي صحيح");
                    return;
                }
                cmd.Parameters.AddWithValue("@Salary", salary);

                DateTime hireDate;
                if (!DateTime.TryParse(HireDate.Text, out hireDate))
                {
                    MessageBox.Show("الرجاء إدخال تاريخ صحيح");
                    return;
                }

                cmd.Parameters.Add("@Hire_Date", SqlDbType.Date).Value = hireDate;
                cmd.Parameters.Add("@Image", SqlDbType.VarBinary).Value = StudentImage;

                con.Open();
                int rows = cmd.ExecuteNonQuery();
                con.Close();

                cmd.Parameters.Clear();

                if (rows > 0)
                {
                    MessageBox.Show("تم اضافة الموظف بنجاح", "معلومة",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Emptying();
                }
                else
                {
                    MessageBox.Show("لم تتم الإضافة إلى قاعدة البيانات");
                }
            }
            else
            {
                MessageBox.Show("الرجاء ادخال كافة البيانات", "تنبيه",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            bind_data("select * from Employees");
        }

        // =========================
        // Bind Data
        // =========================
        private void bind_data(string stringsql)
        {
            con.Open();
            dataGridView1.AutoGenerateColumns = true;
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(stringsql, con);
            da.Fill(dt);

            dataGridView1.DataSource = dt;
            dataGridView1.RightToLeft = RightToLeft.Yes;

            // حماية من الخطأ في VS2012
            if (dataGridView1.Columns.Count < 7)
            {
                con.Close();
                return;
            }


            dataGridView1.Columns[0].HeaderText = "الرقم";
            dataGridView1.Columns[1].HeaderText = "الاسم";
            dataGridView1.Columns[2].HeaderText = "الاسم الاخير";
            dataGridView1.Columns[3].HeaderText = "ارقم";
            dataGridView1.Columns[4].HeaderText = "البريد";
            dataGridView1.Columns[5].HeaderText = "الراتب";
            dataGridView1.Columns[6].HeaderText = "تاريخ التوظيف";
            dataGridView1.Columns[0].Width = 40;
            dataGridView1.Columns[1].Width = 210;
            dataGridView1.Columns[2].Width = 60;
            dataGridView1.Columns[3].Width = 100;
            dataGridView1.Columns[4].Width = 130;
            dataGridView1.Columns[5].Width = 70;
            dataGridView1.Columns[6].Width = 80;

            con.Close();
        }

        
        private void btn_Clear_Click(object sender, EventArgs e)
        {
            Emptying();
        }

      
        private void btn_delete_Click_1(object sender, EventArgs e)
        {
            // التأكد من وجود صف محدد
            if (dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("الرجاء تحديد صف للحذف", "تنبيه",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // جلب رقم الموظف
            int empID = Convert.ToInt32(
                dataGridView1.CurrentRow.Cells["empID"].Value);

            // تأكيد الحذف
            DialogResult result = MessageBox.Show(
                "هل أنت متأكد من حذف هذا السجل؟",
                "تأكيد الحذف",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result != DialogResult.Yes)
                return;

            // تنفيذ الحذف
            SqlCommand cmd = new SqlCommand(
                "DELETE FROM Employees WHERE empID = @empID", con);

            cmd.Parameters.AddWithValue("@empID", empID);

            con.Open();
            int rows = cmd.ExecuteNonQuery();
            con.Close();

            if (rows > 0)
            {
                MessageBox.Show("تم الحذف بنجاح", "معلومة",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                // إعادة تحميل البيانات
                bind_data("select * from Employees");
            }
            else
            {
                MessageBox.Show("لم يتم الحذف", "تنبيه",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
  
    if (dataGridView1.CurrentRow == null)
        return;

    try
    {
        DataGridViewRow row = dataGridView1.CurrentRow;

        First_Name.Text = row.Cells["First_Name"].Value.ToString();
        Last_Name.Text = row.Cells["Last_Name"].Value.ToString();
        Phone_Number.Text = row.Cells["Phone"].Value.ToString();
        Email.Text = row.Cells["Email"].Value.ToString();
        Salary.Text = row.Cells["Salary"].Value.ToString();
        HireDate.Text = Convert.ToDateTime(
            row.Cells["Hire_Date"].Value).ToShortDateString();

        if (row.Cells["Image"].Value != DBNull.Value)
        {
            byte[] imgBytes = (byte[])row.Cells["Image"].Value;
            using (MemoryStream ms = new MemoryStream(imgBytes))
            {
                emp_Profile.Image = Image.FromStream(ms);
            }
            StudentImage = imgBytes;
        }
        else
        {
            emp_Profile.Image = null;
            StudentImage = null;
        }
    }
    catch
    {
        // تجاهل الأخطاء
    }


        }

        private void btn_Edit_Click(object sender, EventArgs e)
        {
            // التأكد من وجود صف محدد
            if (dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("الرجاء تحديد موظف للتعديل", "تنبيه",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // التحقق من البيانات
            if (First_Name.Text.Trim() == "" ||
                Last_Name.Text.Trim() == "" ||
                Phone_Number.Text.Trim() == "" ||
                Email.Text.Trim() == "" ||
                Salary.Text.Trim() == "" ||
                HireDate.Text.Trim() == "")
            {
                MessageBox.Show("الرجاء إدخال جميع البيانات", "تنبيه",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // جلب رقم الموظف
            int empID = Convert.ToInt32(
                dataGridView1.CurrentRow.Cells["empID"].Value);

            // تحويل الراتب
            double salary;
            if (!double.TryParse(Salary.Text, out salary))
            {
                MessageBox.Show("الرجاء إدخال راتب صحيح");
                return;
            }

            // تحويل التاريخ
            DateTime hireDate;
            if (!DateTime.TryParse(HireDate.Text, out hireDate))
            {
                MessageBox.Show("الرجاء إدخال تاريخ صحيح");
                return;
            }

            // كود التعديل
            SqlCommand cmd = new SqlCommand(@"
            UPDATE Employees SET
            First_Name = @First_Name,
            Last_Name  = @Last_Name,
            Phone      = @Phone,
            Email      = @Email,
            Salary     = @Salary,
            Hire_Date  = @Hire_Date,
            Image      = @Image
            WHERE empID = @empID", con);

            cmd.Parameters.AddWithValue("@First_Name", First_Name.Text);
            cmd.Parameters.AddWithValue("@Last_Name", Last_Name.Text);
            cmd.Parameters.AddWithValue("@Phone", Phone_Number.Text);
            cmd.Parameters.AddWithValue("@Email", Email.Text);
            cmd.Parameters.AddWithValue("@Salary", salary);
            cmd.Parameters.Add("@Hire_Date", SqlDbType.Date).Value = hireDate;

            // الصورة (قد تكون لم تتغير)
            if (StudentImage != null)
                cmd.Parameters.Add("@Image", SqlDbType.VarBinary).Value = StudentImage;
            else
                cmd.Parameters.Add("@Image", SqlDbType.VarBinary).Value = DBNull.Value;

            cmd.Parameters.AddWithValue("@empID", empID);

            // تنفيذ
            con.Open();
            int rows = cmd.ExecuteNonQuery();
            con.Close();

            if (rows > 0)
            {
                MessageBox.Show("تم تعديل البيانات بنجاح", "معلومة",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                // تحديث الجدول
                bind_data("select * from Employees");
            }
            else
            {
                MessageBox.Show("لم يتم التعديل", "تنبيه",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            bind_data("select * from  Employees where First_Name like '%" + textBox1.Text + "%'");
        }

    }
}
