﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Hospital1
{
    public partial class depaertmant : Form
    {
        SqlConnection con =
            new SqlConnection("Data Source=AHMED;Initial Catalog=Hospitaldb;Integrated Security=True;");

        public depaertmant()
        {
            InitializeComponent();

            dataGridView1.CellClick += dataGridView1_CellClick;
            bind_data();
        }

        // =========================
        // تحميل البيانات
        // =========================
        private void bind_data()
        {
            SqlDataAdapter da =
                new SqlDataAdapter("SELECT dept_id, dept_name, dept_loc FROM Departments", con);

            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        // =========================
        // تنظيف الحقول
        // =========================
        private void Emptying()
        {
            num_text.Text = "";
            name_text.Text = "";
            loc_text.Text = "";
        }

        // =========================
        // إضافة قسم
        // =========================
        private void btn_add_Click(object sender, EventArgs e)
        {
            if (name_text.Text.Trim() == "" || loc_text.Text.Trim() == "")
            {
                MessageBox.Show("الرجاء إدخال جميع البيانات", "تنبيه");
                return;
            }

            SqlCommand cmd = new SqlCommand(
                "INSERT INTO Departments (dept_name, dept_loc) VALUES (@name, @loc)", con);

            cmd.Parameters.AddWithValue("@name", name_text.Text);
            cmd.Parameters.AddWithValue("@loc", loc_text.Text);

            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("تمت الإضافة بنجاح");
                bind_data();
                Emptying();
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }

        // =========================
        // تعديل قسم
        // =========================
        private void btn_Edit_Click(object sender, EventArgs e)
        {
            if (num_text.Text == "")
            {
                MessageBox.Show("حدد قسمًا من الجدول أولًا");
                return;
            }

            SqlCommand cmd = new SqlCommand(
                @"UPDATE Departments 
                  SET dept_name=@name, dept_loc=@loc 
                  WHERE dept_id=@id", con);

            cmd.Parameters.AddWithValue("@name", name_text.Text);
            cmd.Parameters.AddWithValue("@loc", loc_text.Text);
            cmd.Parameters.AddWithValue("@id", num_text.Text);

            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("تم التعديل بنجاح");
                bind_data();
                Emptying();
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }

        // =========================
        // حذف قسم
        // =========================
        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (num_text.Text == "")
            {
                MessageBox.Show("حدد قسمًا للحذف");
                return;
            }

            DialogResult result = MessageBox.Show(
                "هل أنت متأكد من الحذف؟",
                "تأكيد",
                MessageBoxButtons.YesNo);

            if (result != DialogResult.Yes) return;

            SqlCommand cmd = new SqlCommand(
                "DELETE FROM Departments WHERE dept_id=@id", con);

            cmd.Parameters.AddWithValue("@id", num_text.Text);

            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("تم الحذف بنجاح");
                bind_data();
                Emptying();
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }

        // =========================
        // عند الضغط على صف
        // =========================
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

            num_text.Text = row.Cells[0].Value.ToString();  // dept_id
            name_text.Text = row.Cells[1].Value.ToString(); // dept_name
            loc_text.Text = row.Cells[2].Value.ToString();  // dept_loc
        }

        private void btn_Clear_Click(object sender, EventArgs e)
        {
            Emptying();
        }

        private void loc_dep_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            SqlDataAdapter da =
               new SqlDataAdapter("select * from  Departments where dept_name like '%" + textBox1.Text + "%'", con);

            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void num_dep_Click(object sender, EventArgs e)
        {

        }
    }
}
