﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital1
{
    public partial class Main_Form : Form
    {
        public Main_Form()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }

        private void label1_Click_1(object sender, EventArgs e)
        {
            empl xx = new empl();
            xx.ShowDialog();
        }

        private void label1_MouseEnter(object sender, EventArgs e)
        {
            label1.BackColor = Color.LightSkyBlue;
        }

        private void label1_MouseLeave(object sender, EventArgs e)
        {
            label1.BackColor = SystemColors.MenuHighlight;
        }

        private void btn_depaertmant_Click(object sender, EventArgs e)
        {
            depaertmant xx=new depaertmant();
            xx.ShowDialog();
        }

        private void Clinics_Click(object sender, EventArgs e)
        {
            Clinics xx = new Clinics();
            xx.ShowDialog();
        }


        private void label5_Click(object sender, EventArgs e)
        {
            Main xx = new Main();
            xx.ShowDialog();
        }

        private void Main_Form_Load(object sender, EventArgs e)
        {
            
        }

        private void label6_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        
    }
}
