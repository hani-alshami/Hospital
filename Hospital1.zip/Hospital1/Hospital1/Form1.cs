﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Hospital1
{
    public partial class Form1 : Form
    {

        SqlConnection con = new SqlConnection(@"Data Source=AHMED;Initial Catalog=Hospitaldb;Integrated Security=True;");// هنا تكتب كود الاتصال
        int passwodshow = 0;
        int logins = 0;
        public string name_u;
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (logins < 4)
            {
                if (textBox1.Text.Trim() == "" || textBox2.Text.Trim() == "")
                {
                    MessageBox.Show("  الرجاء إدخال اسم المستخدم او كلمة المرور ", "  تنبيه  ",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                }
                else
                {
                    con.Open();
                    SqlCommand cmd1 = new SqlCommand();
                    cmd1.Connection = con;
                    cmd1.CommandText = "select * from users where user_name =@user_name and user_password=@user_password"; // هنا تعدل الاستعلام على حسب اسماء الاعمدة الموجودة في قاعدة البيانات
                    cmd1.Parameters.AddWithValue("@user_name", textBox1.Text);
                    cmd1.Parameters.AddWithValue("@user_password", textBox2.Text);
                    var rd = cmd1.ExecuteReader();
                    if (rd.Read())
                    {
                        this.Hide();
                        Main_Form f = new Main_Form();
                        f.Tag = rd[0].ToString(); // الاخطاء هذه تظهر عندي لانه لا توجد عندي الصفحة الرئيسية 
                        f.label1.Enabled = bool.Parse(rd[2].ToString());
                        f.btn_depaertmant.Enabled = bool.Parse(rd[3].ToString());
                        f.Clinics.Enabled = bool.Parse(rd[4].ToString());
                        f.User_Management.Enabled = bool.Parse(rd[6].ToString());
                        f.UserName.Text = rd[0].ToString();
                        f.ShowDialog();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show(" تم إدخال كلمة المرور أو اسم المستخدم بشكل خاطئ", " تنبيه ",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                        textBox1.Clear();
                        textBox2.Clear();
                    }
                    con.Close();
                    cmd1.Parameters.Clear();
                    logins++;
                }
            }
            if (logins == 3)
            {
                MessageBox.Show(" المعذرة انتهت محاولات تسجيل الدخول ", " تنبيه",
                     MessageBoxButtons.OK,
                     MessageBoxIcon.Information);
                this.Close();
            }
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            if (textBox2.Text != "")
            {
                if (passwodshow == 0)
                {

                    textBox2.UseSystemPasswordChar = false;
                    passwodshow = 1;
                }
                else
                {
                    textBox2.UseSystemPasswordChar = true;
                    passwodshow = 0;
                }
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label3_Click_1(object sender, EventArgs e)
        {

        }
    }
}
